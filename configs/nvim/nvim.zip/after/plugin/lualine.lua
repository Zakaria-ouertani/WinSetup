require("lualine").setup {
    options = {
        theme = "material"
    }
}
