vim.keymap.set("n", "<leader>e", "<Cmd>Neotree toggle<CR>", {desc = "File Tree"})
