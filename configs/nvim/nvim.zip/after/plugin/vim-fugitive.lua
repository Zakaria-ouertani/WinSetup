vim.keymap.set("n", "<leader>g", vim.cmd.Git, {desc = "Git"})
