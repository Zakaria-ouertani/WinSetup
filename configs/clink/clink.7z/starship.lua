load(io.popen('starship init cmd'):read("*a"))()
