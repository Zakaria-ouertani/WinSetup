require("pip")
require("pip.remaps")
local packer = require("pip.packer")

packer.init({
    max_jobs = 4,
})


