require("nvim-surround").setup({
    keymaps = {
        -- normal = "as",
        -- normal_cur = "ass",
        -- normal_line = "aS",
        -- normal_cur_line = "aSS",
    }
})
